<?php $__env->startSection('title', 'Events'); ?>

<?php $__env->startSection('contents'); ?>

	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title">Events</h3>
			<div class="box-tools">
				<a href="<?php echo e(route('dashboard.events.create')); ?>" class="btn btn-primary btn-flat btn-sm" disabled title="Create Option will be done when Vimeo Live API is provided.">Create new Event</a>
			</div>
		</div>
		<!-- /.box-header -->
		<div class="box-body">
			<table class="table table-bordered">
				<tr>
					<th>#ID</th>
					<th>Title</th>
					<th>Total Bets</th>
					<th>Status</th>
					<th>Live at</th>
					<th>Winner</th>
					<th class="text-right">Actions</th>
				</tr>
				<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><a href="<?php echo e(route('dashboard.events.show', $event->id)); ?>"><?php echo e($event->id); ?></a></td>
						<td><a href="<?php echo e(route('dashboard.events.show', $event->id)); ?>"><?php echo e($event->title); ?></a></td>
						<td><?php echo e($event->bets->count()); ?> <small>(<?php echo e($event->bets->sum('amount')); ?> USD)</small></td>
						<td><?php echo e($event->winner ? 'Ended' : 'Upcoming'); ?></td>
						<td><?php echo e($event->live_at); ?></td>
						<td><?php echo e($event->winner ? $event->winner->name : '-'); ?></td>
						<td class="text-right">
							<a href="<?php echo e(route('dashboard.events.show', $event->id)); ?>" title="View Event" class="btn btn-flat btn-xs btn-primary"><i class="fa fa-eye"></i></a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
		<!-- /.box-body -->
		<?php if($events->total() > 15): ?>
			<div class="box-footer clearfix">
				<?php echo e($events->links('vendor.pagination.default', ['parentClassName' => 'pagination-sm no-margin pull-right'])); ?>

			</div>
		<?php endif; ?>
	</div>
	<!-- /.box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>