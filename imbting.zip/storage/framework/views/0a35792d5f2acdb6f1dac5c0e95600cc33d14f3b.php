<?php $__env->startSection('title', 'All Members'); ?>

<?php $__env->startSection('contents'); ?>

	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title">Banned Members</h3>
			
		</div>
		<!-- /.box-header -->
		<div class="box-body">
			<table class="table table-bordered">
				<tr>
					<th>Firstname</th>
					<th>Lastname</th>
					<th>Username</th>
					<th>Email</th>
					<th>Member from</th>
					<th>Total Bets</th>
					<th>Bet (Win)</th>
					<th>Bet (Lose)</th>
					<th>Pending (Risked Amount)</th>
					<th>Balance</th>
					<th class="text-right">Actions</th>
				</tr>
				<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($user->firstname); ?></td>
						<td><?php echo e($user->lastname); ?></td>
						<td><?php echo e($user->username); ?></td>
						<td><?php echo e($user->email); ?></td>
						<td><?php echo e($user->created_at->toFormattedDateString()); ?></td>
						<td>
							<?php echo e($user->bets->count()); ?>

						</td>
						<td>
							<?php $winningBets = winningBets($user->bets); ?>
							<?php echo e($winningBets->count()); ?>

							<small>
								(<?php echo e($winningBets->sum('amount')); ?> USD)
							</small>
						</td>
						<td>
							<?php $losingBets = losingBets($user->bets); ?>
							<?php echo e($losingBets->count()); ?>

							<small>
								(<?php echo e($losingBets->sum('amount')); ?> USD)
							</small>
						</td>
						<td>
							<?php $pendingBets = pendingBets($user->bets); ?>
							<small>
								<?php echo e($pendingBets->count()); ?> (<?php echo e($pendingBets->sum('amount')); ?> USD)
							</small>
						</td>
						<td>
							<?php
								$debit = $user->transactions->where('type', 1)->sum('amount');
								$credit = $user->transactions->where('type', 0)->sum('amount');
							?>
							<?php echo e($debit - $credit); ?> <small>USD</small>
						</td>
						<td class="text-right">
							<a href="<?php echo e(route('dashboard.members.show', $user->id)); ?>" class="btn btn-xs btn-flat btn-primary" title="View Member Profile"><i class="fa fa-eye"></i></a>
							<a href="#" data-toggle="modal" data-target="#member-<?php echo e($user->id); ?>-unban-modal" class="btn btn-xs btn-flat btn-danger" title="Remove Ban from this member"><i class="fa fa-circle-o"></i></a>
							<?php echo $__env->make('dashboard.members.partials._modal-unban-member', compact('user'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
		<?php if($users->total() > 15): ?>
			<div class="box-footer clearfix">
				<?php echo e($users->links('vendor.pagination.default', ['parentClassName' => 'pagination-sm no-margin pull-right'])); ?>

			</div>
		<?php endif; ?>
	</div>
	<!-- /.box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>