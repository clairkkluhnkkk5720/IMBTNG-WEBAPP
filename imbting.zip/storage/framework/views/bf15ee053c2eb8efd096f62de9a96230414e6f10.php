<?php $__env->startSection('title', 'Admins'); ?>

<?php $__env->startSection('contents'); ?>

	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title">Admins</h3>
			<div class="box-tools">
				<a href="<?php echo e(route('dashboard.admins.create')); ?>" class="btn btn-primary btn-flat btn-sm">Create new Admin</a>
			</div>
		</div>
		<!-- /.box-header -->
		<div class="box-body">
			<table class="table table-bordered">
				<tr>
					<th>Firstname</th>
					<th>Lastname</th>
					<th>Email</th>
					<th>Phone</th>
					<th>Member from</th>
					<th class="text-right">Actions</th>
				</tr>
				<?php echo $__env->renderEach('dashboard.admins.partials._single-admin', $admins, 'admin'); ?>
			</table>
		</div>
		<!-- /.box-body -->
		<?php if($admins->total() > 15): ?>
			<div class="box-footer clearfix">
				<?php echo e($admins->links('vendor.pagination.default', ['parentClassName' => 'pagination-sm no-margin pull-right'])); ?>

			</div>
		<?php endif; ?>
	</div>
	<!-- /.box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>