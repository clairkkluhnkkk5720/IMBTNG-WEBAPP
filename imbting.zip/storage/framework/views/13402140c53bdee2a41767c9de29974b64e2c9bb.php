<?php $__env->startSection('title', 'Reset password'); ?>


<?php $__env->startSection('contents'); ?>

	<p class="login-box-msg">Reset Password.</p>

	

	<form action="<?php echo e(route('dashboard.password.reset.post')); ?>" method="post">
		<div class="form-group has-feedback <?php if($errors->has('email')): ?> has-error <?php endif; ?>">
			<input type="email" name="email" class="form-control" placeholder="Email Address" value="<?php echo e(isset($email) ? $email : old('email')); ?>" required>
			<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
			<?php if($errors->has('email')): ?>
				<span class="help-block"><?php echo e($errors->first('email')); ?></span>
			<?php endif; ?>
		</div>
		<div class="form-group has-feedback <?php if($errors->has('password')): ?> has-error <?php endif; ?>">
			<input type="password" name="password" class="form-control" placeholder="New Password" required>
			<span class="glyphicon glyphicon-lock form-control-feedback"></span>
			<?php if($errors->has('password')): ?>
				<span class="help-block"><?php echo e($errors->first('password')); ?></span>
			<?php endif; ?>
		</div>
		<div class="form-group has-feedback <?php if($errors->has('password_confirmation')): ?> has-error <?php endif; ?>">
			<input type="password" name="password_confirmation" class="form-control" placeholder="New Password_confirmation" required>
			<span class="glyphicon glyphicon-lock form-control-feedback"></span>
			<?php if($errors->has('password_confirmation')): ?>
				<span class="help-block"><?php echo e($errors->first('password_confirmation')); ?></span>
			<?php endif; ?>
		</div>
		<?php echo e(csrf_field()); ?>

		<input type="hidden" name="token" value="<?php echo e($token); ?>">
		<button type="submit" class="btn btn-primary btn-block btn-flat">Reset Password</button>
	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>