<tr>
	<td><?php echo e($admin->firstname); ?></td>
	<td><?php echo e($admin->lastname); ?></td>
	<td><?php echo e($admin->email); ?></td>
	<td><?php echo e($admin->phone); ?></td>
	<td><?php echo e($admin->created_at->toFormattedDateString()); ?></td>
	<td class="text-right">
		<a href="<?php echo e(route('dashboard.admins.trash.show', $admin->id)); ?>" class="btn btn-xs btn-flat btn-success" title="View Admin Profile">
			<i class="fa fa-eye"></i>
		</a>
		<a href="#" class="btn btn-xs btn-flat btn-primary"><i class="fa fa-window-restore"></i></a>
		<a href="#" class="btn btn-xs btn-flat btn-danger"><i class="fa fa-trash"></i></a>
	</td>
</tr>