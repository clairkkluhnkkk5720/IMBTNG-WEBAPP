<?php $__env->startSection('title', 'Reset password'); ?>


<?php $__env->startSection('contents'); ?>

	<p class="login-box-msg">Please fill this form.</p>

	

	<form action="<?php echo e(route('dashboard.password.email')); ?>" method="post">
		<div class="form-group has-feedback <?php if($errors->has('email')): ?> has-error <?php endif; ?>">
			<input type="email" name="email" class="form-control" placeholder="Email Address" required>
			<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
			<?php if($errors->has('email')): ?>
				<span class="help-block"><?php echo e($errors->first('email')); ?></span>
			<?php endif; ?>
		</div>
		<?php echo e(csrf_field()); ?>

		<button type="submit" class="btn btn-primary btn-block btn-flat">Send Password Reset Mail</button>
	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>