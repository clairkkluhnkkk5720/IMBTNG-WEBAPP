<?php $__env->startSection('title', $p_title); ?>

<?php $__env->startSection('contents'); ?>

	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title"><?php echo e($p_title); ?> of <a href="<?php echo e(route('dashboard.members.show', $user->id)); ?>"><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></a></h3>
			
		</div>
		<!-- /.box-header -->
		<div class="box-body">
			<table class="table table-bordered">
				<tr>
					<th>Event</th>
					<th>Amount</th>
					<th>Player</th>
					<th>Bet Placed at</th>
					<th>Status</th>
				</tr>
				<?php $__currentLoopData = $bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($bet->event->title); ?></td>
						<td><?php echo e($bet->amount); ?></td>
						<td><?php echo e($bet->player->name); ?></td>
						<td><?php echo e($bet->created_at); ?></td>
						<td><?php echo e(getBetStatus($bet)); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
		
	</div>
	<!-- /.box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>