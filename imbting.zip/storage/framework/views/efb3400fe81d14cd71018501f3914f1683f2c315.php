<?php $__env->startSection('title', 'Create Role'); ?>

<?php $__env->startSection('contents'); ?>

	<div class="box box-primary">
		<div class="box-header with-border">
			<h3 class="box-title">Create Role</h3>
		</div>
		<!-- /.box-header -->
		<form role="form" method="POST" action="<?php echo e(route('dashboard.roles.store')); ?>">
			<div class="box-body">
				<div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
					<label for="role-name">Role Name *</label>
					<input type="text" name="name" class="form-control" id="role-name" value="<?php echo e(old('name')); ?>" placeholder="Enter Role Name" >
					<?php if($errors->has('name')): ?>
						<span class="help-block"><?php echo e($errors->first('name')); ?></span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php if($errors->has('details')): ?> has-error <?php endif; ?>">
					<label for="role-details">Role Details <small>(optional)</small></label>
					<textarea row="2" class="form-control" name="details" id="role-details" placeholder="Enter Role Details"><?php echo e(old('details')); ?></textarea>
					<?php if($errors->has('details')): ?>
						<span class="help-block"><?php echo e($errors->first('details')); ?></span>
					<?php endif; ?>
				</div>
				<div class="checkbox">
					<hr>
					<h4>Choose Permission:</h4>
					<?php if($errors->has('permissions')): ?>
						<p class="text-danger"><?php echo e($errors->first('permissions')); ?></p>
					<?php endif; ?>
					<hr>
				</div>
				<div class="row">
					<?php echo $__env->renderEach('dashboard.roles.partials._single-permission-checkbox', $permissions, 'permission'); ?>
				</div>
			</div>
			<!-- /.box-body -->

			<div class="box-footer">
				<?php echo e(csrf_field()); ?>

				<button type="submit" class="btn btn-primary btn-flat">CREATE</button>
			</div>
		</form>
	</div>
	<!-- /.box -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

	<!-- iCheck for checkboxes and radio inputs -->
	<link rel="stylesheet" href="/dashboard-assets/plugins/iCheck/all.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

	<!-- iCheck 1.0.1 -->
	<script src="/dashboard-assets/plugins/iCheck/icheck.min.js"></script>

	<script>
		//iCheck for checkbox and radio inputs
		$('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
			checkboxClass: 'icheckbox_minimal-blue',
			radioClass   : 'iradio_minimal-blue'
		});
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>