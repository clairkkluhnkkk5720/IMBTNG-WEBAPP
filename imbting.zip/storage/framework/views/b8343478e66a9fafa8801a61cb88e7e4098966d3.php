<aside class="main-sidebar">
	<!-- sidebar: style can be found in sidebar.less -->
	<section class="sidebar">
		<!-- Sidebar user panel -->
		<div class="user-panel">
			<div class="pull-left image">
				<img src="<?php echo e(asset('/dashboard-assets/dist/img/user2-160x160.jpg')); ?>" class="img-circle" alt="User Image">
			</div>
			<div class="pull-left info">
				<p><?php echo e(admin()->firstname); ?> <?php echo e(admin()->lastname); ?></p>
				<a href="#"><i class="fa fa-circle text-success"></i> Online</a>
			</div>
		</div>
		<!-- sidebar menu: : style can be found in sidebar.less -->
		<ul class="sidebar-menu" data-widget="tree">

			<li <?php if(currentRouteName() === 'dashboard.index'): ?> class="active" <?php endif; ?>>
				<a href="<?php echo e(route('dashboard.index')); ?>">
					<i class="fa fa-dashboard"></i> <span>Dashboard</span>
				</a>
			</li>

			

			<li class="treeview <?php if(strpos(currentRouteName(), 'dashboard.members.') !== false): ?> active menu-open <?php endif; ?>">
				<a href="#">
					<i class="fa fa-users"></i>
					<span>Members</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
				<ul class="treeview-menu">
					<li <?php if(currentRouteName() === 'dashboard.members.index'): ?> class="active" <?php endif; ?>>
						<a href="<?php echo e(route('dashboard.members.index')); ?>"><i class="fa fa-circle-o"></i> All Members</a>
					</li>
					<li <?php if(currentRouteName() === 'dashboard.members.banned'): ?> class="active" <?php endif; ?>>
						<a href="<?php echo e(route('dashboard.members.banned')); ?>"><i class="fa fa-circle-o"></i> Banned Members</a>
					</li>
				</ul>
			</li>

			<li <?php if(currentRouteName() === 'dashboard.events.index'): ?> class="active" <?php endif; ?>>
				<a href="<?php echo e(route('dashboard.events.index')); ?>"><i class="fa fa-clone"></i> <span>Events</span></a>
			</li>

			<li <?php if(currentRouteName() === 'dashboard.bets.index'): ?> class="active" <?php endif; ?>>
				<a href="<?php echo e(route('dashboard.bets.index')); ?>"><i class="fa fa-usd"></i> <span>Bets</span></a>
			</li>

			<li class="treeview <?php if(strpos(currentRouteName(), 'dashboard.admins.') !== false): ?> active menu-open <?php endif; ?>">
				<a href="#">
					<i class="fa fa-users"></i>
					<span>Admins</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
				<ul class="treeview-menu">
					<li <?php if(currentRouteName() === 'dashboard.admins.index'): ?> class="active" <?php endif; ?>>
						<a href="<?php echo e(route('dashboard.admins.index')); ?>"><i class="fa fa-circle-o"></i> All Admins</a>
					</li>
					<li <?php if(currentRouteName() === 'dashboard.admins.create'): ?> class="active" <?php endif; ?>>
						<a href="<?php echo e(route('dashboard.admins.create')); ?>"><i class="fa fa-circle-o"></i> Create New Admin</a>
					</li>
					<li>
						<a href="<?php echo e(route('dashboard.admins.trash.index')); ?>"><i class="fa fa-circle-o"></i> Trash</a>
					</li>
				</ul>
			</li>

			<li class="treeview <?php if(strpos(currentRouteName(), 'dashboard.roles.') !== false): ?> active menu-open <?php endif; ?>">
				<a href="#">
					<i class="fa fa-universal-access"></i>
					<span>Roles</span>
					<span class="pull-right-container">
						<i class="fa fa-angle-left pull-right"></i>
					</span>
				</a>
				<ul class="treeview-menu">
					<li <?php if(currentRouteName() === 'dashboard.roles.index'): ?> class="active" <?php endif; ?>>
						<a href="<?php echo e(route('dashboard.roles.index')); ?>"><i class="fa fa-circle-o"></i> All Roles</a>
					</li>
					<li <?php if(currentRouteName() === 'dashboard.roles.create'): ?> class="active" <?php endif; ?>>
						<a href="<?php echo e(route('dashboard.roles.create')); ?>"><i class="fa fa-circle-o"></i> Create New Role</a>
					</li>
				</ul>
			</li>
		</ul>
	</section>
	<!-- /.sidebar -->
</aside>