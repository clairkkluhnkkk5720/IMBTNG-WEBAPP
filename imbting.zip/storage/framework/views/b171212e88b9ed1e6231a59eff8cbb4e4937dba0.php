<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('contents'); ?>

	<?php echo $__env->make('dashboard.admins.partials._modal-delete-admin', compact('admin'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="row">
		<div class="col-lg-3 col-md-4">
			<div class="box box-danger">
				<div class="box-body box-profile">
					<img class="profile-user-img img-responsive img-circle" src="/dashboard-assets/dist/img/user4-128x128.jpg" alt="User profile picture">
					<h3 class="profile-username text-center"><?php echo e($admin->firstname); ?> <?php echo e($admin->lastname); ?></h3>
					<a href="#" data-toggle="modal" data-target="#admin-<?php echo e($admin->id); ?>-delete-modal" class="btn btn-danger btn-block btn-flat"><b>DELETE ADMIN</b></a>
				</div>
			</div>
		</div>

		<div class="col-lg-3 col-md-4">
			<div class="box box-info">
				<div class="box-header with-border">
					<h3 class="box-title">Info:</h3>
				</div>
				<div class="box-body">
					<p>Firstname: <strong><?php echo e($admin->firstname); ?></strong></p>
					<p>Lastname: <strong><?php echo e($admin->lastname); ?></strong></p>
					<p>Email: <strong><?php echo e($admin->email); ?></strong></p>
					<p>Phone: <strong><?php echo e($admin->phone); ?></strong></p>
					<p>Member From: <strong><?php echo e($admin->created_at->toFormattedDateString()); ?></strong></p>
				</div>
				<div class="box-footer">
					<a href="<?php echo e(route('dashboard.admins.edit', $admin->id)); ?>" class="btn btn-info btn-block btn-flat"><b>EDIT ADMIN INFO</b></a>
				</div>
			</div>
		</div>

		<div class="col-lg-3 col-md-4">
			<div class="box-success box">
				<div class="box-header with-border">
					<h3 class="box-title">Roles:</h3>
				</div>
				<div class="box-body">
					<?php echo $__env->renderEach('dashboard.admins.partials._single-role', $roles, 'role'); ?>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>