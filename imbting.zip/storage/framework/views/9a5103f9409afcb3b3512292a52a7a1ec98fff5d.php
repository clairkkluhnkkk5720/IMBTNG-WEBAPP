<tr>
	<td><?php echo e(formatPermissionName($permission->name)); ?></td>
	<td><?php echo e($permission->details); ?></td>
	<td class="text-right">
		<a href="#" class="btn btn-warning btn-xs btn-flat" title="Remove this permission from role." data-toggle="modal" data-target="#role-permission-<?php echo e($permission->id); ?>-delete-modal">Remove Permission</a>
		<?php echo $__env->make('dashboard.roles.partials._modal-remove-role-permission', compact('role', 'permission'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</td>
</tr>