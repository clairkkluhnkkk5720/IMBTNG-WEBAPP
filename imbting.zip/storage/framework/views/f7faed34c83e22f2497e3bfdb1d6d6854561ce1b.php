<?php $__env->startSection('title', 'Login'); ?>


<?php $__env->startSection('contents'); ?>

	<p class="login-box-msg">Please Login to Continue</p>

	

	<form action="<?php echo e(route('dashboard.login.post')); ?>" method="post">
		<div class="form-group has-feedback <?php if($errors->has('email')): ?> has-error <?php endif; ?>">
			<input type="email" name="email" class="form-control" placeholder="Email Address" value="<?php echo e(old('email')); ?>" required>
			<span class="glyphicon glyphicon-envelope form-control-feedback"></span>
			<?php if($errors->has('email')): ?>
				<span class="help-block"><?php echo e($errors->first('email')); ?></span>
			<?php endif; ?>
		</div>
		<div class="form-group has-feedback <?php if($errors->has('password')): ?> has-error <?php endif; ?>">
			<input type="password" name="password" class="form-control" placeholder="Password" required>
			<span class="glyphicon glyphicon-lock form-control-feedback"></span>
			<?php if($errors->has('password')): ?>
				<span class="help-block"><?php echo e($errors->first('password')); ?></span>
			<?php endif; ?>
		</div>
		<div class="row">
			<div class="col-xs-8">
				<div class="checkbox icheck">
					<label><input name="remember" type="checkbox">&nbsp;&nbsp;&nbsp;Remember Me</label>
				</div>
			</div>
			<!-- /.col -->
			<div class="col-xs-4">
				<?php echo e(csrf_field()); ?>

				<button type="submit" class="btn btn-primary btn-block btn-flat">Login</button>
			</div>
			<!-- /.col -->
		</div>
	</form>

	<br>

	<a href="<?php echo e(route('dashboard.password.request')); ?>">I forgot my password</a><br>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.auth', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>