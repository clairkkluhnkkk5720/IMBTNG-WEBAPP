<h4><?php echo e($role->name); ?></h4>
<p><?php echo e($role->details); ?></p>
<a href="<?php echo e(route('dashboard.roles.show', $role->id)); ?>" class="btn btn-sm btn-success btn-flat">View Role</a>
<hr>