<?php $__env->startSection('title', 'All Bets'); ?>

<?php $__env->startSection('contents'); ?>

	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title">Bets</h3>
			
		</div>
		<!-- /.box-header -->
		<div class="box-body">
			<table class="table table-bordered">
				<tr>
					<th>#ID</th>
					<th>Event</th>
					<th>Athlete/Team</th>
					<th>User</th>
					<th>Amount</th>
					<th>Status</th>
				</tr>
				<?php $__currentLoopData = $bets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($bet->id); ?></td>
						<td><a href="<?php echo e(route('dashboard.events.show', $bet->event->id)); ?>"><?php echo e($bet->event->title); ?></a></td>
						<td><?php echo e($bet->player->name); ?></td>
						<td><a href="<?php echo e(route('dashboard.members.show', $bet->user->id)); ?>"><?php echo e($bet->user->firstname); ?> <?php echo e($bet->user->lastname); ?></a></td>
						<td><?php echo e($bet->amount); ?> <small>USD</small></td>
						<td><?php echo e(getBetStatus($bet)); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
		<!-- /.box-body -->
		<?php if($bets->total() > 15): ?>
			<div class="box-footer clearfix">
				<?php echo e($bets->links('vendor.pagination.default', ['parentClassName' => 'pagination-sm no-margin pull-right'])); ?>

			</div>
		<?php endif; ?>
	</div>
	<!-- /.box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>