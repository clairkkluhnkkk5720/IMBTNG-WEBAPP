<?php $__env->startSection('title', 'Update Admin'); ?>

<?php $__env->startSection('contents'); ?>

	<form class="row" method="POST" action="<?php echo e(route('dashboard.admins.update', $admin->id)); ?>">
		<?php echo e(csrf_field()); ?>

		<?php echo e(method_field('PUT')); ?>

		<div class="col-md-6">
			<div class="box box-success">
				<div class="box-header with-border">
					<h3 class="box-title">Update Admin Info</h3>
				</div>
				<div class="box-body">
					<div class="row">
						<div class="col-lg-6">
							<div class="form-group <?php if($errors->has('firstname')): ?> has-error <?php endif; ?>">
								<label for="admin-firstname">Firstname</label>
								<input type="text" class="form-control" id="admin-firstname" name="firstname" placeholder="Firstname" value="<?php echo e($admin->firstname); ?>" required>
								<?php if($errors->has('firstname')): ?>
									<span class="help-block"><?php echo e($errors->first('firstname')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group <?php if($errors->has('lastname')): ?> has-error <?php endif; ?>">
								<label for="admin-lastname">Lastname</label>
								<input type="text" class="form-control" id="admin-lastname" name="lastname" placeholder="Lastname" value="<?php echo e($admin->lastname); ?>" required>
								<?php if($errors->has('lastname')): ?>
									<span class="help-block"><?php echo e($errors->first('lastname')); ?></span>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-6">
							<div class="form-group <?php if($errors->has('email')): ?> has-error <?php endif; ?>">
								<label for="admin-email">Email Address</label>
								<input type="email" class="form-control" id="admin-email" name="email" placeholder="Email Address" value="<?php echo e($admin->email); ?>" required>
								<?php if($errors->has('email')): ?>
									<span class="help-block"><?php echo e($errors->first('email')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group <?php if($errors->has('phone')): ?> has-error <?php endif; ?>">
								<label for="admin-phone">Phone</label>
								<input type="phone" class="form-control" id="admin-phone" name="phone" placeholder="Phone" value="<?php echo e($admin->phone); ?>" required>
								<?php if($errors->has('phone')): ?>
									<span class="help-block"><?php echo e($errors->first('phone')); ?></span>
								<?php endif; ?>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-lg-6">
							<div class="form-group <?php if($errors->has('password')): ?> has-error <?php endif; ?>">
								<label for="admin-password">Password</label>
								<input type="password" class="form-control" id="admin-password" name="password" placeholder="Password">
								<?php if($errors->has('password')): ?>
									<span class="help-block"><?php echo e($errors->first('password')); ?></span>
								<?php endif; ?>
							</div>
						</div>
						<div class="col-lg-6">
							<div class="form-group <?php if($errors->has('password_confirmation')): ?> has-error <?php endif; ?>">
								<label for="admin-password_confirmation">Confirm Password</label>
								<input type="text" class="form-control" id="admin-password_confirmation" name="password_confirmation" placeholder="Confirm Password" value="<?php echo e(old('password_confirmation')); ?>">
								<?php if($errors->has('password_confirmation')): ?>
									<span class="help-block"><?php echo e($errors->first('password_confirmation')); ?></span>
								<?php endif; ?>
							</div>
						</div>
					</div>
				</div>
				<div class="box-footer visible-md visible-lg">
					<button type="submit" class="btn btn-md btn-success btn-flat">UPDATE ADMIN</button>
				</div>
			</div>
		</div>

		<div class="col-md-6">
			<div class="box box-primary">
				<div class="box-header width-border">
					<h3 class="box-title">Assign Role:</h3>
				</div>
				<div class="box-body">
					<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="form-group">
							<label>
								<input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>" class="minimal" 
									<?php if(in_array($role->id, $adminRoles)): ?>
										checked
									<?php endif; ?>
								>
								&nbsp;&nbsp;<?php echo e($role->name); ?>

								<p style="font-weight: normal; padding-left: 27px;"><?php echo e($role->details); ?></p>
							</label>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
				<div class="box-footer hidden-md hidden-lg">
					<button type="submit" class="btn btn-md btn-success btn-flat">UPDATE ADMIN</button>
				</div>
			</div>
		</div>
	</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>

	<!-- iCheck for checkboxes and radio inputs -->
	<link rel="stylesheet" href="/dashboard-assets/plugins/iCheck/all.css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

	<!-- iCheck 1.0.1 -->
	<script src="/dashboard-assets/plugins/iCheck/icheck.min.js"></script>

	<script>
		//iCheck for checkbox and radio inputs
		$('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
			checkboxClass: 'icheckbox_minimal-blue',
			radioClass   : 'iradio_minimal-blue'
		});
	</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>