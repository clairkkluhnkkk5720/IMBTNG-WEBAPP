<tr>
	<td><?php echo e($admin->firstname); ?></td>
	<td><?php echo e($admin->lastname); ?></td>
	<td><?php echo e($admin->email); ?></td>
	<td><?php echo e($admin->phone); ?></td>
	<td><?php echo e($admin->created_at->toFormattedDateString()); ?></td>
	<td class="text-right">
		<a href="<?php echo e(route('dashboard.admins.show', $admin->id)); ?>" class="btn btn-xs btn-success btn-flat" title="View Profile"><i class="fa fa-eye"></i></a>
		<a href="<?php echo e(route('dashboard.admins.edit', $admin->id)); ?>" class="btn btn-xs btn-primary btn-flat" title="Edit this Admin Profile"><i class="fa fa-pencil"></i></a>
		<a href="#" data-toggle="modal" data-target="#admin-<?php echo e($admin->id); ?>-delete-modal" class="btn btn-xs btn-danger btn-flat" title="Delete this Admin"><i class="fa fa-trash"></i></a>
		<?php echo $__env->make('dashboard.admins.partials._modal-delete-admin', compact('admin'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</td>
</tr>