<div class="form-group">
	<label>
		<input type="checkbox" name="roles[]" value="<?php echo e($role->id); ?>" class="minimal" 
			<?php if(old('roles') and is_array(old('roles')) and in_array($role->id, old('permissions')) ): ?>
				checked
			<?php endif; ?>
		>
		&nbsp;&nbsp;<?php echo e($role->name); ?>

		<p style="font-weight: normal; padding-left: 27px;"><?php echo e($role->details); ?></p>
	</label>
</div>