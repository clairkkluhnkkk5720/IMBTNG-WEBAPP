<?php $__env->startSection('title', 'Roles'); ?>

<?php $__env->startSection('contents'); ?>

	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title">Roles</h3>
			<div class="box-tools">
				<a href="<?php echo e(route('dashboard.roles.create')); ?>" class="btn btn-primary btn-flat btn-sm">Create new Role</a>
			</div>
		</div>
		<!-- /.box-header -->
		<div class="box-body">
			<table class="table table-bordered">
				<tr>
					<th>Name</th>
					<th>Details</th>
					<th>Total Permissions</th>
					<th>Total Admins</th>
					<th class="text-right">Actions</th>
				</tr>
				<?php echo $__env->renderEach('dashboard.roles.partials._single-role', $roles, 'role'); ?>
			</table>
		</div>
		<!-- /.box-body -->
		<?php if($roles->total() > 15): ?>
			<div class="box-footer clearfix">
				<?php echo e($roles->links('vendor.pagination.default', ['parentClassName' => 'pagination-sm no-margin pull-right'])); ?>

			</div>
		<?php endif; ?>
	</div>
	<!-- /.box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>