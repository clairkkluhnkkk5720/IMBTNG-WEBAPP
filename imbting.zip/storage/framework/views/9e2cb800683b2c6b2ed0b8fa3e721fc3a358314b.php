<?php $__env->startSection('title', 'Transactions'); ?>

<?php $__env->startSection('contents'); ?>

	<div class="box">
		<div class="box-header with-border">
			<h3 class="box-title">Transactions of <a href="<?php echo e(route('dashboard.members.show', $user->id)); ?>"><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></a></h3>
			
		</div>
		<!-- /.box-header -->
		<div class="box-body">
			<table class="table table-bordered">
				<tr>
					<th>#ID</th>
					<th>Member</th>
					<th>Type</th>
					<th>Amount</th>
					<th>Details</th>
				</tr>
				<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($t->id); ?></td>
						<td><?php echo e($t->user->firstname); ?> <?php echo e($t->user->lastname); ?></td>
						<td><?php echo e($t->type ? 'Credit' : 'Debit'); ?></td>
						<td><?php echo e($t->amount); ?> USD</td>
						<td><?php echo e($t->details); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
		
		<div class="box-footer clearfix">
			<h4>Balance: <strong><?php echo e($transactions->where('type', 1)->sum('amount') - $transactions->where('type', 0)->sum('amount')); ?> USD</strong></h4>
		</div>
	</div>
	<!-- /.box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>