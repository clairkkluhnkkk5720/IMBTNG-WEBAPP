<?php $__env->startSection('title', 'Role'); ?>

<?php $__env->startSection('contents'); ?>

	<?php echo $__env->make('dashboard.roles.partials._modal-delete-role', compact('role'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="box box-primary">
		<div class="box-header with-border">
			<h3 class="box-title">Role</h3>
			<div class="box-tools">
				<a href="<?php echo e(route('dashboard.roles.edit', $role->id)); ?>" class="btn btn-primary btn-flat btn-sm" title="Edit this role.">Edit</a>
				<a href="#" class="btn btn-danger btn-flat btn-sm" title="Delete this role." data-toggle="modal" data-target="#role-<?php echo e($role->id); ?>-delete-modal">Delete</a>
			</div>
		</div>
		<div class="box-body">
			<h4>Name: <strong><?php echo e($role->name); ?></strong></h4>
			<p>Details: <strong><?php echo e($role->details); ?></strong></p>
			<hr>
			<div class="row">
				<div class="col-lg-6">
					<h4>Permissions:</h4>
					<hr>
					<table class="table table-bordered">
						<tr>
							<th>Name</th>
							<th>Details</th>
							<th class="text-right">Actions</th>
						</tr>
						<?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php echo $__env->make('dashboard.roles.partials._single-role-permission', compact('role', 'permission'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</table>
				</div>
				<div class="col-lg-6">
					<h4>Admins:</h4>
					<hr>
					<table class="table table-bordered">
						<tr>
							<th>Name</th>
							<th>Email</th>
							<th>Phone</th>
							<th class="text-right">Actions</th>
						</tr>
						<?php echo $__env->renderEach('dashboard.roles.partials._single-role-admin', $admins, 'admin'); ?>
					</table>
				</div>
			</div>
		</div>
	</div>
	<!-- /.box -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>