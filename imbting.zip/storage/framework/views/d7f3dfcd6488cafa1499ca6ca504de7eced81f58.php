<tr>
	<td><a href="<?php echo e(route('dashboard.roles.show', $role->id)); ?>"><?php echo e($role->name); ?></a></td>
	<td><?php echo e($role->details); ?></td>
	<td><?php echo e($role->permissions_count); ?></td>
	<td><?php echo e($role->admins_count); ?></td>
	<td class="text-right">
		<a href="<?php echo e(route('dashboard.roles.show', $role->id)); ?>" class="btn btn-xs btn-success btn-flat" title="View this role."><i class="fa fa-eye"></i></a>
		<a href="<?php echo e(route('dashboard.roles.edit', $role->id)); ?>" class="btn btn-xs btn-primary btn-flat" title="Edit this role."><i class="fa fa-pencil"></i></a>
		<a href="#" data-toggle="modal" data-target="#role-<?php echo e($role->id); ?>-delete-modal" class="btn btn-xs btn-danger btn-flat" title="Delete this role."><i class="fa fa-trash"></i></a>
		<?php echo $__env->make('dashboard.roles.partials._modal-delete-role', compact('role'), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	</td>
</tr>