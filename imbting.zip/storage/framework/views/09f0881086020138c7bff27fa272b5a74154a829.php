<?php $__env->startSection('title', 'Event'); ?>

<?php $__env->startSection('contents'); ?>

	

	<!-- Info boxes -->
	<div class="row">
		<div class="col-md-4 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-aqua"><i class="fa fa-clock-o"></i></span>

				<div class="info-box-content">
					<span class="info-box-text">Live at</span>
					<span class="info-box-number">
						<?php echo e($event->live_at->toDateTimeString()); ?>

					</span>
				</div>
				<!-- /.info-box-content -->
			</div>
			<!-- /.info-box -->
		</div>
		<!-- /.col -->

		<!-- fix for small devices only -->
		<div class="clearfix visible-sm-block"></div>

		<div class="col-md-4 col-sm-6 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-green"><i class="fa fa-signal"></i></span>

				<div class="info-box-content">
					<span class="info-box-text">Status</span>
					<span class="info-box-number">
						<?php echo e($event->winner ? 'Ended' : 'Upcoming'); ?>

					</span>
				</div>
				<!-- /.info-box-content -->
			</div>
			<!-- /.info-box -->
		</div>
		<!-- /.col -->

		<div class="col-md-4 col-sm-12 col-xs-12">
			<div class="info-box">
				<span class="info-box-icon bg-yellow"><i class="fa fa-usd"></i></span>

				<div class="info-box-content">
					<span class="info-box-text">Total Bets</span>
					<span class="info-box-number">
						<?php echo e($bets->count()); ?> (<?php echo e($bets->sum('amount')); ?> USD)
					</span>
				</div>
				<!-- /.info-box-content -->
			</div>
			<!-- /.info-box -->
		</div>
		<!-- /.col -->
	</div>
	<!-- /.row -->

	<div class="row">
		<div class="col-lg-12">
			<div class="box box-info">
				<div class="box-header with-border">
					<h3 class="box-title">Event Info:</h3>
				</div>
				<div class="box-body">
					<p>Title: <strong><?php echo e($event->title); ?></strong></p>
					<p>Details: <strong><?php echo e($event->details ? $event->details : 'NULL'); ?></strong></p>
					<p>Athletes/Teams: </p>
					<ul>
						<?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li><strong><?php echo e($player->name); ?></strong> <small>(<?php echo e($bets->where('player_id', $player->id)->count()); ?> Bets, <?php echo e($bets->where('player_id', $player->id)->sum('amount')); ?> USD)</small></li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</ul>
					
				</div>
				
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>