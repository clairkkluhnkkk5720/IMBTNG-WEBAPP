<tr>
	<td><a href="#">{{ $admin->firstname }} {{ $admin->lastname }}</a></td>
	<td>{{ $admin->email }}</td>
	<td>{{ $admin->phone }}</td>
	<td class="text-right">
		<a href="#" title="Remove this Admin from this role." class="btn btn-warning btn-xs btn-flat">Remove from Role</a>
	</td>
</tr>